Learn Node.js by Example

Copyright C. A. Cois (www.codehenge.net), 2012

This code represents one example solution to the Additional Coding Exercises for Project 2, a webserver inplemented in Node.js. I want to stress that there are many ways of adding the requested functionality, depending on the application being developed and many potential other constraints. I've chosen to implement this example in what I see as the simplest, most straightforward way. Hopefully this makes the solution easy to read and understand. I do not claim this to be the most elegant, or the most efficient solution, merely a working solution directed towards learning to work with Node.js as a web application stack.

I've commented to the code throughout with information to help you understand my thought processes in implementing a solution.

As always, please feel free to contact me with any questions.

Cheers, 
    Aaron